#import <Flutter/Flutter.h>

@interface ContactsServicePlugin : NSObject<FlutterPlugin>
@end
